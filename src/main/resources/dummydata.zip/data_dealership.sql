INSERT INTO Dealership(DealershipId, Address, State, ZipCode)
VALUES
  (111,'2742 Velit Rd.','Utah','787157'),
  (112,'649-9720 Amet St.','Arizona','52881'),
  (113,'Ap #424-4026 Dui St.','Utah','26565'),
  (114,'356-9612 Sed Ave','Georgia','58528'),
  (115,'Ap #520-7611 Semper St.','Texas','488322'),
  (116,'268 Suspendisse Rd.','Oklahoma','195555'),
  (117,'Ap #404-4538 Blandit Road','Delaware','65839'),
  (118,'492-2778 Ridiculus St.','Virginia','57262'),
  (119,'5302 Elementum, Road','Illinois','89-21'),
  (120,'978-6997 Fermentum Av.','Maryland','30403');
INSERT INTO Dealership(DealershipId, Address, State, ZipCode)
VALUES
  (121,'Ap #976-7757 Eu Avenue','Florida','4860'),
  (122,'Ap #350-5081 Augue Rd.','Texas','R7V 8X4'),
  (123,'Ap #439-1230 Dictum. St.','Vermont','705545'),
  (124,'P.O. Box 551, 7272 Augue St.','Oklahoma','232586'),
  (125,'2541 Vitae Avenue','Alaska','892595'),
  (126,'Ap #442-582 Ridiculus Avenue','Pennsylvania','3455'),
  (127,'624-628 Tincidunt Avenue','Virginia','71255'),
  (128,'Ap #556-632 Scelerisque Av.','Arkansas','76710-568'),
  (129,'473-1340 Vivamus St.','Vermont','5245'),
  (130,'Ap #686-4811 Orci Avenue','Wyoming','67406-020');
INSERT INTO Dealership(DealershipId, Address, State, ZipCode)
VALUES
  (131,'Ap #753-9063 Nec St.','Idaho','41669'),
  (132,'791-1968 Luctus, Rd.','Idaho','2735'),
  (133,'208-3513 Mauris St.','Montana','28726'),
  (134,'Ap #437-1662 Eu Rd.','Connecticut','3717'),
  (135,'6335 Elit. Ave','Nebraska','44284'),
  (136,'2393 Aliquet Avenue','Georgia','3554'),
  (137,'461-9986 Nam Rd.','Iowa','210471'),
  (138,'640-1144 Non Rd.','Alaska','476767'),
  (139,'Ap #493-7579 Malesuada Rd.','Indiana','657629'),
  (140,'116-7878 Sit St.','California','7453');
